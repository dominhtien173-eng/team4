#include <stdio.h>
#include <stdlib.h>

int main() {
    int choice;
    double balance = 2685310952; 
    double debt = 900000000;      
    double amount;
    char name[50];
    int repayWay;
//viet menu bao gom: check so du, rut tien, chuyen tien, nap, vay, tong du no, tra no (cos 2 cach tra: tra bang tien trong account san co or nap tien vo de tra), thoats trang
    do {
        printf("\n=== Please select the service you want to use ===\n");
        printf("1. Check current balance\n");
        printf("2. Withdraw money\n");
        printf("3. Transfer money\n");
        printf("4. Deposit money\n");
        printf("5. Take a loan\n");
        printf("6. Check debt balance\n");
        printf("7. Repay debt\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
//check so du
        if (choice == 1) {
            printf("Your current balance is: %.2f VND\n", balance);
        } 
        //Rut tien. Nhap tien muon rut, so tien k hop le, khong du tien va hoan thanhf + so du moi
        else if (choice == 2) {
            printf("Enter the amount you want to withdraw: ");
            scanf("%lf", &amount);
            if (amount <= 0) {
                printf("Invalid amount!\n");
            } else if (amount > balance) {
                printf("Not enough money!\n");
            } else {
                balance = balance - amount;
                printf("Withdraw successful! New balance: %.2f\n", balance);
            }
            //Chuyen tien cho ngta. Nhap ten nguoi minh muon chuyen, nhap so tien can chuyen cho nguoi ta, loi neu het tien giong choice 2, in ra da chuyen bao tien cho ai va in ra so du moi
        }
        else if (choice == 3) {
            printf("Enter receiver name: ");
            scanf("%s", name);
            printf("Enter amount to transfer: ");
            scanf("%lf", &amount);
            if (amount <= 0) {
                printf("Invalid amount!\n");
            } else if (amount > balance) {
                printf("Not enough money to transfer!\n");
            } else {
                balance = balance - amount;
                printf("You transferred %.2f VND to %s\n", amount, name);
                printf("New balance: %.2f VND\n", balance);
            }
            //nap tien vo. Nhap so tien muon nap, tien k hop le. so du moi bang so du cu + so tien moi nap
        }
        else if (choice == 4) {
            printf("Enter amount to deposit: ");
            scanf("%lf", &amount);
            if (amount <= 0) {
                printf("Invalid amount!\n");
            } else {
                balance = balance + amount;
                printf("Deposit successful! New balance: %.2f VND\n", balance);
            }
            //Vay tien. Nhap soos tien muon vay, loi neu tien k hop le, in ra da muon duoc tien, du no hien tai va so du
        }
        else if (choice == 5) {
            printf("Enter loan amount: ");
            scanf("%lf", &amount);
            if (amount <= 0) {
                printf("Invalid amount!\n");
            } else {
                debt = debt + amount;
                balance = balance + amount;
                printf("You took a loan of %.2f VND\n", amount);
                printf("Debt now: %.2f VND\n", debt);
                printf("Balance now: %.2f VND\n", balance);
            }
            //Tra no. In ra do no hien tai, cos 2 phuong an tra no 1.Tra bang so du 2.Tra bang tien nap vao
            //1.Nhap vo so tien muon tra, neu k du tien thi bao k du tien, neu co thi tra (so du - no = so du moi)
        }
        else if (choice == 6) {
            printf("Your current debt: %.2f VND\n", debt);
        }
        else if (choice == 7) {
            printf("1. Repay using current balance\n");
            printf("2. Deposit money and repay\n");
            printf("Choose how to repay: ");
            scanf("%d", &repayWay);

            if (repayWay == 1) {
                printf("Enter amount to repay: ");
                scanf("%lf", &amount);
                if (amount > balance) {
                    printf("Not enough money in your account!\n");
                } else if (amount > debt) {
                    printf("You repaid your debt: %.2f VND\n", debt);
                    balance = balance - debt;
                    debt = 0;
                } else {
                    debt = debt - amount;
                    balance = balance - amount;
                    printf("You repaid %.2f VND, remaining debt: %.2f VND\n", amount, debt);
                }
            //2.Nap tien vo roi tra cho Bank. So du moi = so du cu + so tien nap vao, neu so tien nap vao > no => tra het no. Tuong tu nhu v tinh so no khong tra full
            }
            else if (repayWay == 2) {
                printf("Enter amount to deposit for repayment: ");
                scanf("%lf", &amount);
                balance = balance + amount;
                if (amount > debt) {
                    printf("Debt fully repaid: %.2f VND\n", debt);
                    balance = balance - debt;
                    debt = 0;
                } else {
                    debt = debt - amount;
                    balance = balance - amount;
                    printf("You repaid %.2f VND, remaining debt: %.2f VND\n", amount, debt);
                }
            } 
            else {
                printf("Invalid option!\n");
            }
        //thoat. cam on khach cac thu vi da su dung dich vu cua ngan hang con meo (cute vai)
        }
        else if (choice == 8) {
            printf("Cat Bank sincerely thanks you for your trust and patronage. We wish you a wonderful day ahead!\n");
        }
        else {
            printf("Invalid choice!\n");
        }

    } while (choice != 8);

    return 0;
}

