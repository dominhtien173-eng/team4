#include <stdio.h>
#include <stdlib.h>

int main() {
    int day, month, year, userChoose;

    printf("Enter your day, month, year: ");
    scanf("%d %d %d", &day, &month, &year);

    printf("Enter your choose:\n");
    printf("1. Print your current age\n");
    printf("2. Print your zodiac\n");
    printf("3. Print your wishes\n");
    printf("4. Check your leap year\n");

    printf("Your choose: ");
    scanf("%d", &userChoose);

    switch (userChoose) {
        case 1: {
            int currentAge = 2025 - year;
            printf("Your current age is: %d\n", currentAge);
            break;
        }

        case 2: {
            switch (month) {
                case 1:
                    if (day <= 19)
                        printf("Your zodiac is: Capricorn");
                    else
                        printf("Your zodiac is: Aquarius");
                    break;
                case 2:
                    if (day <= 18)
                        printf("Your zodiac is: Aquarius");
                    else
                        printf("Your zodiac is: Pisces");
                    break;
                case 3:
                    if (day <= 20)
                        printf("Your zodiac is: Pisces");
                    else
                        printf("Your zodiac is: Aries");
                    break;
                case 4:
                    if (day <= 19)
                        printf("Your zodiac is: Aries");
                    else
                        printf("Your zodiac is: Taurus");
                    break;
                case 5:
                    if (day <= 20)
                        printf("Your zodiac is: Taurus");
                    else
                        printf("Your zodiac is: Gemini");
                    break;
                case 6:
                    if (day <= 20)
                        printf("Your zodiac is: Gemini");
                    else
                        printf("Your zodiac is: Cancer");
                    break;
                case 7:
                    if (day <= 22)
                        printf("Your zodiac is: Cancer");
                    else
                        printf("Your zodiac is: Leo");
                    break;
                case 8:
                    if (day <= 22)
                        printf("Your zodiac is: Leo");
                    else
                        printf("Your zodiac is: Virgo");
                    break;
                case 9:
                    if (day <= 22)
                        printf("Your zodiac is: Virgo");
                    else
                        printf("Your zodiac is: Libra");
                    break;
                case 10:
                    if (day <= 22)
                        printf("Your zodiac is: Libra");
                    else
                        printf("Your zodiac is: Scorpio");
                    break;
                case 11:
                    if (day <= 21)
                        printf("Your zodiac is: Scorpio");
                    else
                        printf("Your zodiac is: Sagittarius");
                    break;
                case 12:
                    if (day <= 21)
                        printf("Your zodiac is: Sagittarius");
                    else
                        printf("Your zodiac is: Capricorn");
                    break;
                default:
                    printf("Invalid month");
            }
            break;
        }

        case 3: {
            int sum_date = (day / 10) + (day % 10) + (month / 10) + (month % 10);
            int lucky_number = (day + month * 2 + sum_date * 3) % 10;
            printf("Your lucky number is: %d\n", lucky_number);

            switch (lucky_number) {
                case 0: printf("Wish: You will find peace and happiness soon.\n"); break;
                case 1: printf("Wish: A new opportunity will come your way.\n"); break;
                case 2: printf("Wish: You will meet someone inspiring.\n"); break;
                case 3: printf("Wish: Good luck will follow you today.\n"); break;
                case 4: printf("Wish: Fuckyou bitch.\n"); break;
                case 5: printf("Wish: You will achieve your dream soon.\n"); break;
                case 6: printf("Wish: Expect a surprise gift from someone.\n"); break;
                case 7: printf("Wish: Happiness and health will be with you.\n"); break;
                case 8: printf("Wish: I hope you feel what i felt when you sharred my soul.\n"); break;
                case 9: printf("Wish: You will get love from Song Ninnn !\n"); break;
                default: printf("Wish: Keep smiling and stay positive!\n");
            }
            break;
	}
        case 4:
            if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
                printf("%d is a leap year.\n", year);
            else
                printf("%d is not a leap year.\n", year);
            break;

        default:
            printf("Invalid choose!\n");
    }

    return 0;
}

