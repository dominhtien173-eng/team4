#include <stdio.h>

int main() {
    int choice;

    printf("===== Wishlist =====\n");
    printf("1. Take a week off from studying\n");
    printf("2. Skip studying but still pass the course\n");
    printf("3. Pray for my parents'\n");
    printf("Enter your choice (1-3): ");
    scanf("%d", &choice);

    if (choice == 1) {
        printf("\nHaha! A week off? You think success takes vacations too? Keep dreaming, buddy!\n");
    }
    else if (choice == 2) {
        printf("\n\"If you want to eat without working, the only thing you'll eat is dirt.\"\n");
    }
    else if (choice == 3) {
        printf("\nTo my beloved Mom and Dad,\n");
        printf("I am always proud to be your child. Thank you for giving me life,\n");
        printf("for raising me with love, patience, and endless care.\n");
        printf("Thank you for accepting and supporting the real me no matter what.\n");
        printf("I know I�m luckier than so many others in this world.\n");
        printf("Whenever I feel stressed or tired, Mom always says:\n");
        printf("\"I�m so proud of you, my dear. Keep going, my love.\"\n");
        printf("And Dad, in your quiet way, you just tell me:\n");
        printf("\"Take care of your health, son/daughter � it�s the most important thing.\"\n");
        printf("Everything I�ve achieved today is because of you both.\n");
        printf("Through this little letter, I wish you both good health and true happiness.\n");
        printf("Mom, please remember to wear warm clothes and use your moisturizer.\n");
        printf("Dad, please try to get more sleep, okay?\n");
        printf("Love you forever \n");
    }
    else {
        printf("\nInvalid choice! Please select 1, 2 or 3.\n");
    }

    return 0;
}

